/* Starfleet India Capital Advisors — site.js (no dependencies) */
(function () {
  'use strict';

  var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)');

  /* ---- Header: transparent at top, blurred once the page scrolls ---- */
  var header = document.querySelector('[data-header]');
  function syncHeader() {
    header.classList.toggle('is-scrolled', window.scrollY > 24);
  }
  syncHeader();
  window.addEventListener('scroll', syncHeader, { passive: true });

  /* ---- Hero: lift the night layer once the orbital image is ready ---- */
  var hero = document.querySelector('[data-hero]');
  var heroImg = document.querySelector('[data-hero-img]');
  var lit = false;
  function lightHero() {
    if (lit) return;
    lit = true;
    requestAnimationFrame(function () {
      requestAnimationFrame(function () { hero.classList.add('is-lit'); });
    });
  }
  if (hero) {
    if (reduceMotion.matches || !heroImg || (heroImg.complete && heroImg.naturalWidth)) {
      lightHero();
    } else {
      heroImg.addEventListener('load', lightHero, { once: true });
      heroImg.addEventListener('error', lightHero, { once: true });
    }
    window.setTimeout(lightHero, 2500); // never leave the hero dark
  }

  /* ---- Mobile menu ---- */
  var toggle = document.querySelector('[data-menu-toggle]');
  var menu = document.querySelector('[data-mobile-menu]');
  function setMenu(open) {
    toggle.setAttribute('aria-expanded', String(open));
    menu.hidden = !open;
    header.classList.toggle('menu-open', open);
    document.body.style.overflow = open ? 'hidden' : '';
  }
  if (toggle && menu) {
    toggle.addEventListener('click', function () {
      setMenu(toggle.getAttribute('aria-expanded') !== 'true');
    });
    menu.addEventListener('click', function (e) {
      if (e.target.closest('a')) setMenu(false);
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && toggle.getAttribute('aria-expanded') === 'true') {
        setMenu(false);
        toggle.focus();
      }
    });
    window.matchMedia('(min-width: 1081px)').addEventListener('change', function (e) {
      if (e.matches) setMenu(false);
    });
  }

  /* ---- Pillars: gentle rise as they enter the viewport ---- */
  var reveals = document.querySelectorAll('[data-reveal]');
  if (!('IntersectionObserver' in window) || reduceMotion.matches) {
    reveals.forEach(function (el) { el.classList.add('is-visible'); });
  } else {
    var revealObserver = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          revealObserver.unobserve(entry.target);
        }
      });
    }, { rootMargin: '0px 0px -10% 0px', threshold: 0.15 });
    reveals.forEach(function (el) { revealObserver.observe(el); });
  }

  /* ---- Dropdowns: pillars, sectors and services all share one disclosure pattern ---- */
  document.querySelectorAll('[data-disclosure]').forEach(function (box) {
    var toggle = box.querySelector('[data-disclosure-toggle]');
    var panel = box.querySelector('[data-disclosure-panel]');
    if (!toggle || !panel) return;
    function set(open) {
      box.classList.toggle('is-open', open);
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
      panel.inert = !open;
    }
    set(false);
    toggle.addEventListener('click', function () {
      set(toggle.getAttribute('aria-expanded') !== 'true');
    });
  });

  /* ---- Primary nav: mark the section currently in view ---- */
  var navLinks = Array.prototype.slice.call(document.querySelectorAll('.site-nav a[href^="#"]'));
  if ('IntersectionObserver' in window && navLinks.length) {
    var byId = {};
    navLinks.forEach(function (a) { byId[a.getAttribute('href').slice(1)] = a; });
    var spyTargets = Object.keys(byId).concat('top')
      .map(function (id) { return document.getElementById(id); })
      .filter(Boolean);
    var spy = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (!entry.isIntersecting) return;
        navLinks.forEach(function (a) { a.removeAttribute('aria-current'); });
        var link = byId[entry.target.id];
        if (link) link.setAttribute('aria-current', 'true');
      });
    }, { rootMargin: '-45% 0px -50% 0px' });
    spyTargets.forEach(function (el) { spy.observe(el); });
  }
})();
